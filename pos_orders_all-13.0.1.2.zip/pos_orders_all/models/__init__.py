# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import pos
from . import pos_coupon
from . import pos_coupons_config
from . import sale
from . import pos_custom_discount
from . import pos_return_barcode
from . import pos_order_report
from . import account_invoice

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
